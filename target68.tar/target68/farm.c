/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_383(unsigned x)
{
    return x + 2425378861U;
}

unsigned addval_489(unsigned x)
{
    return x + 3284633932U;
}

void setval_422(unsigned *p)
{
    *p = 3284633928U;
}

void setval_159(unsigned *p)
{
    *p = 2425394264U;
}

unsigned getval_304()
{
    return 1477183454U;
}

void setval_268(unsigned *p)
{
    *p = 3281293400U;
}

unsigned getval_213()
{
    return 3351742792U;
}

void setval_313(unsigned *p)
{
    *p = 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_400(unsigned *p)
{
    *p = 3524840073U;
}

void setval_292(unsigned *p)
{
    *p = 3224420745U;
}

unsigned getval_275()
{
    return 3251276229U;
}

void setval_386(unsigned *p)
{
    *p = 2429192447U;
}

unsigned addval_266(unsigned x)
{
    return x + 2430638408U;
}

unsigned addval_188(unsigned x)
{
    return x + 3531921035U;
}

unsigned addval_450(unsigned x)
{
    return x + 3269495112U;
}

unsigned getval_351()
{
    return 3767077040U;
}

unsigned getval_251()
{
    return 3766569048U;
}

unsigned getval_469()
{
    return 3224950401U;
}

unsigned addval_336(unsigned x)
{
    return x + 3674786441U;
}

unsigned addval_364(unsigned x)
{
    return x + 3376988553U;
}

unsigned getval_154()
{
    return 3286276424U;
}

unsigned getval_197()
{
    return 3281043841U;
}

unsigned addval_247(unsigned x)
{
    return x + 3527983497U;
}

void setval_147(unsigned *p)
{
    *p = 2425542281U;
}

unsigned getval_412()
{
    return 3525891721U;
}

void setval_133(unsigned *p)
{
    *p = 3372799624U;
}

unsigned addval_179(unsigned x)
{
    return x + 3281043849U;
}

unsigned getval_494()
{
    return 3526934921U;
}

unsigned getval_216()
{
    return 247715465U;
}

unsigned getval_423()
{
    return 3682912905U;
}

unsigned getval_126()
{
    return 2425667977U;
}

unsigned addval_103(unsigned x)
{
    return x + 3229931145U;
}

void setval_225(unsigned *p)
{
    *p = 3232025225U;
}

unsigned addval_239(unsigned x)
{
    return x + 3767093405U;
}

unsigned getval_413()
{
    return 3375939849U;
}

unsigned addval_290(unsigned x)
{
    return x + 3286239560U;
}

unsigned getval_348()
{
    return 180606600U;
}

void setval_114(unsigned *p)
{
    *p = 2430634312U;
}

unsigned addval_145(unsigned x)
{
    return x + 2730674825U;
}

void setval_355(unsigned *p)
{
    *p = 3222850185U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
