/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_375(unsigned x)
{
    return x + 3351742792U;
}

unsigned getval_382()
{
    return 2425393240U;
}

unsigned addval_224(unsigned x)
{
    return x + 1343115392U;
}

void setval_174(unsigned *p)
{
    *p = 432232511U;
}

unsigned getval_426()
{
    return 3284633928U;
}

unsigned addval_400(unsigned x)
{
    return x + 3281147980U;
}

unsigned addval_262(unsigned x)
{
    return x + 3347663062U;
}

unsigned getval_440()
{
    return 2496104776U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_104()
{
    return 2425673353U;
}

void setval_289(unsigned *p)
{
    *p = 3526937225U;
}

unsigned addval_155(unsigned x)
{
    return x + 1136907977U;
}

unsigned getval_338()
{
    return 683920008U;
}

unsigned getval_259()
{
    return 3281046153U;
}

void setval_343(unsigned *p)
{
    *p = 3523791489U;
}

unsigned addval_163(unsigned x)
{
    return x + 2425405865U;
}

unsigned getval_484()
{
    return 2447411528U;
}

unsigned addval_394(unsigned x)
{
    return x + 3677932041U;
}

unsigned addval_249(unsigned x)
{
    return x + 2447411528U;
}

unsigned getval_470()
{
    return 3767093299U;
}

unsigned getval_391()
{
    return 3523794573U;
}

void setval_415(unsigned *p)
{
    *p = 3373845129U;
}

unsigned getval_398()
{
    return 2497743176U;
}

void setval_119(unsigned *p)
{
    *p = 3678980745U;
}

unsigned getval_123()
{
    return 3372799629U;
}

unsigned getval_127()
{
    return 3221804683U;
}

void setval_275(unsigned *p)
{
    *p = 2428602770U;
}

void setval_218(unsigned *p)
{
    *p = 3767093313U;
}

unsigned getval_183()
{
    return 2447411528U;
}

unsigned getval_241()
{
    return 3678978441U;
}

unsigned addval_177(unsigned x)
{
    return x + 3234125449U;
}

unsigned addval_468(unsigned x)
{
    return x + 3525362057U;
}

void setval_411(unsigned *p)
{
    *p = 3400136795U;
}

unsigned getval_451()
{
    return 3771287790U;
}

unsigned addval_209(unsigned x)
{
    return x + 3677405577U;
}

void setval_399(unsigned *p)
{
    *p = 3677935241U;
}

unsigned getval_419()
{
    return 3353381192U;
}

void setval_172(unsigned *p)
{
    *p = 3250686310U;
}

unsigned addval_464(unsigned x)
{
    return x + 2425667977U;
}

void setval_323(unsigned *p)
{
    *p = 3676356873U;
}

unsigned addval_441(unsigned x)
{
    return x + 3677935241U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
